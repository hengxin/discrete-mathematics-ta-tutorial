#include "AlgebraicStructure.h"
#include "iostream"

using namespace std;
AlgebraicStructure::AlgebraicStructure(void)
{
	reset();
	operation = NULL;
}


AlgebraicStructure::~AlgebraicStructure(void)
{
	if(card > 0 && operation != NULL) {
		for(int i = 0; i < card; i++) {
			if(operation[i] != NULL) delete [](operation[i]);
		}
		delete []operation;
		operation = 0;
	}
}

void AlgebraicStructure::input() {
	char ch;
	while(1) {
		ch = cin.get();
		if(ch == 13 || ch == 10) {
			ch = cin.get();
			if(ch != 10) {
				cin.putback(ch);
			}
			break;
		}
		alphabet[card] = ch;
		alphHashtable[ch] = card;
		card++;
	}
	operation = new int *[card];
	for(int i = 0; i < card; i++) {
		operation[i] = new int[card];
	}
	for(int i = 0; i < card; i++) {
		char temp[129];
		cin >> temp;
		for(int j = 0; j < card; j++) {
			operation[i][j] = alphHashtable[temp[j]];
		}
	}
	//identity
	for(int i = 0; i < card; i++) {
		bool isIdentity = true;
		for(int j = 0; j < card; j++) {
			if(operation[i][j] != j || operation[j][i] != j) {
				isIdentity = false;
				break;
			}
		}
		if(isIdentity == true) {
			identity = i;
			break;
		}
	}
}

void AlgebraicStructure::output() {
	cout << "* |";
	for(int i = 0; i < card; i++) {
		cout << " " << alphabet[i];
	}
	cout << endl << "--+";
	for(int i = 0; i < 2 * card; i++) {
		cout << "-";
	}
	cout << endl;
	for(int i = 0 ; i < card; i++) {
		cout << alphabet[i] << " |";
		for(int j = 0; j < card; j++) {
			cout << " " << alphabet[operation[i][j]];
		}
		cout << endl;
	}
}

void AlgebraicStructure::outputDetermination() {
	if(isAssociative()) {
		cout << "semigroup" << endl;
		if(identity > -1) {
			cout << "monoid" << endl;
			if(isInverse()) {
				cout << "group" << endl;
			} else {
				cout << "not group" << endl;
			}
		} else {
			cout << "not monoid" << endl;
			cout << "not group" << endl;
		}
	} else {
		cout << "not semigroup" << endl;
		cout << "not monid" << endl;
		cout << "not group" << endl;
	}
}

bool AlgebraicStructure::isAssociative() {
	bool result = true;
	for(int i = 0; i < card; i++) {
		for(int j = 0; j < card; j++) {
			for(int k = 0; k < card; k++) {
				if(operation[operation[i][j]][k] != operation[i][operation[j][k]]) {
					result = false;
					break;
				}
			}
		}
	}
	return result;
}

char AlgebraicStructure::getIdentity() {
	if(identity < 0) return '\0';
	return alphabet[identity];
}

bool AlgebraicStructure::isInverse() {
	bool result = true;
	for(int i = 0; i < card; i++) {
		if(getInverse(i) < 0) {
			result = false;
			break;
		}
	}
	return result;
}

char AlgebraicStructure::getInverse(char element) {
	int inverse = getInverse(alphHashtable[element]);
	if(inverse > -1) {
		return alphabet[inverse];
	} else {
		return '\0';
	}
}

int AlgebraicStructure::getInverse(int index) {
	int inverse = -1;
	if(identity < 0) return -1;
	for(int i = 0; i < card; i++) {
		if(operation[index][i] == identity && operation[i][index] == identity) {
			inverse = i;
			break;
		}
	}
	return inverse;
}


void AlgebraicStructure::reset() {
	card = 0;
	identity = '\0';
	for(int i = 0; i < 128; i++) {
		alphHashtable[i] = -1;
		alphabet[i] = '\0';
	}
	alphabet[128] = '\0';	
}
