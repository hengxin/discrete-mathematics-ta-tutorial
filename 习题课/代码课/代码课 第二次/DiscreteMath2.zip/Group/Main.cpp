#include "iostream"
#include "AlgebraicStructure.h"

int main(int argc, char** argv) {
	AlgebraicStructure a1;
	a1.input();
	a1.output();
	a1.outputDetermination();

	return 0;
}