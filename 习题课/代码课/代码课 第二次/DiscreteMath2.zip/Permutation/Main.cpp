#include "Permutation.h"

int main() {

	Permutation p;
	p.input();
	p.outputDetermination();
	return 0;
}