#include "Permutation.h"
#include "iostream"

using namespace std;
Permutation::Permutation(void)
{
	card = 0;
	permutation = NULL;
}


Permutation::~Permutation(void)
{
	if(card > 0 && permutation != NULL) delete []permutation;
}

void Permutation::input() {
	int num = -1;
	char ch;
	while(1) {
		ch = cin.get();
		if(ch == 13 || ch == 10) {
			card++;
			break;
		}
		if(ch == ' ') {
			card++;
		}
	}
	permutation = new int[card];
	for(int i = 0; i < card; i++) {
		cin >> num;
		permutation[i] = num - 1;
	}
}

void Permutation::outputDetermination() {
	bool* tag = new bool[card];
	int count = 0;
	for(int i = 0; i < card; i++) tag[i] = false;
	while(1) {
		int start = 0;
		for(; start < card; start++) {
			if(!tag[start]) break;
		}
		if(start == card) break;

		int next = start;
		while(1) {
			tag[next] = true;
			next = permutation[next];
			if(next == start) {
				break;
			} else {
				count++;
			}
		}
	}
	delete []tag;
	if(count % 2 == 0) {
		cout << "even";
	} else {
		cout << "odd";
	}
	cout << endl;
}