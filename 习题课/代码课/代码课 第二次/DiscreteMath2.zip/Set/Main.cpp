#include "Set.h"
#include "cstring"
#include "fstream"
#include "iostream"
using namespace std;

int main(int argc, char** argv) {

		Set a, b;
		ifstream ins("d:\\Set.txt");
	
	
		a.setInput(ins);
		a.setOutput("d:\\setOutput.txt");
		b.setInput(ins);
		b.setOutput("d:\\setOutput.txt");
		Set f = a.setIntersect(b);
		Set e = a.setUnion(b);
		Set g = a.setComplement(b);
		Set h = a.setComplement();
		f.setOutput("d:\\setOutput.txt");
		e.setOutput("d:\\setOutput.txt");
		g.setOutput("d:\\setOutput.txt");
		h.setOutput("d:\\setOutput.txt");

		ins.close();
	return 0;
}